<nav>
    <ol>
        <li><a href="/">Home</a></li>
        <li><a href="about">About</a></li>
        <li><a href="music">Music</a></li>
        <li><a href="appearances">Appearances</a></li>
        <li><a href="contact">Contact</a></li>
    </ol>
</nav>
